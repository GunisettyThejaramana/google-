import React, { useState } from 'react';
import { Search, Grid3X3, User } from 'lucide-react';

function App() {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="min-h-screen bg-white flex flex-col">
      {/* Top Navigation */}
      <nav className="flex justify-end items-center p-4 text-sm">
        <div className="flex items-center space-x-4">
          <a href="#" className="text-gray-700 hover:underline">Gmail</a>
          <a href="#" className="text-gray-700 hover:underline">Images</a>
          <button className="p-2 hover:bg-gray-100 rounded-full">
            <Grid3X3 size={20} className="text-gray-600" />
          </button>
          <button className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition-colors">
            Sign in
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 flex flex-col items-center justify-center px-4 -mt-20">
        {/* Google Logo */}
        <div className="mb-8">
          <h1 className="text-8xl font-normal select-none">
            <span className="text-blue-500">G</span>
            <span className="text-red-500">o</span>
            <span className="text-yellow-500">o</span>
            <span className="text-blue-500">g</span>
            <span className="text-green-500">l</span>
            <span className="text-red-500">e</span>
          </h1>
        </div>

        {/* Search Container */}
        <div className="w-full max-w-2xl">
          {/* Search Bar */}
          <div className="relative mb-8">
            <div className="flex items-center w-full border border-gray-300 rounded-full px-4 py-3 shadow-sm hover:shadow-md focus-within:shadow-md transition-shadow">
              <Search size={20} className="text-gray-400 mr-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 outline-none text-base"
                autoComplete="off"
              />
              {searchQuery && (
                <button 
                  onClick={() => setSearchQuery('')}
                  className="ml-3 text-gray-400 hover:text-gray-600"
                >
                  ×
                </button>
              )}
            </div>
          </div>

          {/* Buttons */}
          <div className="flex justify-center space-x-4">
            <button className="bg-gray-50 text-gray-700 px-5 py-2 rounded border border-gray-300 hover:border-gray-400 hover:shadow-sm transition-all text-sm">
              Google Search
            </button>
            <button className="bg-gray-50 text-gray-700 px-5 py-2 rounded border border-gray-300 hover:border-gray-400 hover:shadow-sm transition-all text-sm">
              I'm Feeling Lucky
            </button>
          </div>
        </div>

        {/* Language Options */}
        <div className="mt-8 text-sm text-gray-500">
          Google offered in: 
          <a href="#" className="text-blue-600 hover:underline ml-1">हिन्दी</a>
          <a href="#" className="text-blue-600 hover:underline ml-1">বাংলা</a>
          <a href="#" className="text-blue-600 hover:underline ml-1">తెలుగు</a>
          <a href="#" className="text-blue-600 hover:underline ml-1">मराठी</a>
          <a href="#" className="text-blue-600 hover:underline ml-1">தமிழ்</a>
          <a href="#" className="text-blue-600 hover:underline ml-1">ગુજરાતી</a>
          <a href="#" className="text-blue-600 hover:underline ml-1">ಕನ್ನಡ</a>
          <a href="#" className="text-blue-600 hover:underline ml-1">മലയാളം</a>
          <a href="#" className="text-blue-600 hover:underline ml-1">ਪੰਜਾਬੀ</a>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-100 border-t border-gray-200">
        <div className="px-4 py-3 text-gray-600 text-sm">
          <div className="text-center mb-2">India</div>
        </div>
        <div className="border-t border-gray-200 px-4 py-3">
          <div className="flex flex-col md:flex-row justify-between items-center text-sm text-gray-600 space-y-2 md:space-y-0">
            <div className="flex flex-wrap justify-center md:justify-start space-x-6">
              <a href="#" className="hover:underline">About</a>
              <a href="#" className="hover:underline">Advertising</a>
              <a href="#" className="hover:underline">Business</a>
              <a href="#" className="hover:underline">How Search works</a>
            </div>
            <div className="flex flex-wrap justify-center md:justify-end space-x-6">
              <a href="#" className="hover:underline">Privacy</a>
              <a href="#" className="hover:underline">Terms</a>
              <a href="#" className="hover:underline">Settings</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;